/* design-build · self-critique: Clarity5 Warmth4 Restraint5 Craft4 Variety3 SlopFree5 */
import { toast } from 'sonner'
import { useState } from 'react'
import {
  Autocomplete,
  Box,
  Button,
  Checkbox,
  Chip,
  Container,
  FormControl,
  FormControlLabel,
  IconButton,
  InputLabel,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Stack,
  Switch,
  TextField,
  Typography,
} from '@mui/material'
import type { ButtonProps } from '@mui/material/Button'
import type { ReactNode } from 'react'
import ArrowOutwardOutlined from '@mui/icons-material/ArrowOutwardOutlined'
import ContentCopyOutlined from '@mui/icons-material/ContentCopyOutlined'
import CloseOutlined from '@mui/icons-material/CloseOutlined'
import MoreHorizOutlined from '@mui/icons-material/MoreHorizOutlined'
import EditOutlined from '@mui/icons-material/EditOutlined'
import ArchiveOutlined from '@mui/icons-material/ArchiveOutlined'
import DeleteOutlineOutlined from '@mui/icons-material/DeleteOutlineOutlined'
import { PlaceSheet } from '../../components/PlaceSheet'
import ArrowBackOutlined from '@mui/icons-material/ArrowBackOutlined'
import DescriptionOutlined from '@mui/icons-material/DescriptionOutlined'
import PushPin from '@mui/icons-material/PushPin'
import PhoneOutlined from '@mui/icons-material/PhoneOutlined'
import { PlaceIconButton } from '../../components/PlaceIconButton'
import { CardActionButton } from '../../components/CardActionButton'
import { Eyebrow } from '../../components/Eyebrow'
import { FactList } from '../../components/FactList'
import { HeadlineStat, Stat } from '../../components/Stat'
import { PortalOutlineTag } from '../../components/PortalOutlineTag'
import { PlaceModal, placeModalWidths, type PlaceModalSize } from '../../components/PlaceModal'
import { SegmentedSwitch, type SegmentedSwitchOption } from '../../components/SegmentedSwitch'
import { typographyTokens } from '../../design-tokens'
import { ListingDetailsSheet } from '../../seller-portal/ListingDetailsSheet'
import { sampleSellerTransaction } from '../../seller-portal/sellerTransaction'
import { EmailPreview } from '../../email-templates/EmailPreview'
import { emailTemplates } from '../../email-templates/emailTemplates'

const sections = [
  { id: 'typography', name: 'Typography' },
  { id: 'colors', name: 'Colors' },
  { id: 'button', name: 'Button' },
  { id: 'icon-button', name: 'Icon button' },
  { id: 'chip', name: 'Chip' },
  { id: 'segmented-switch', name: 'Segmented switch' },
  { id: 'paper', name: 'Paper' },
  { id: 'modal', name: 'Modal' },
  { id: 'sheet', name: 'Sheet' },
  { id: 'toast', name: 'Toast' },
  { id: 'menu', name: 'Menu' },
  { id: 'form-controls', name: 'Form controls' },
  { id: 'eyebrow', name: 'Eyebrow' },
  { id: 'stat', name: 'Stat' },
  { id: 'fact-list', name: 'Fact list' },
  { id: 'listing-sheet', name: 'Listing sheet' },
  { id: 'email-blocks', name: 'Email blocks' },
] as const

const modalSizes = Object.keys(placeModalWidths) as PlaceModalSize[]

const typographyGroups: { name: string; variants: (keyof typeof typographyTokens)[]; sample: string }[] = [
  { name: 'Display', variants: ['displayL', 'displayM', 'displayS'], sample: 'A place to call home' },
  { name: 'Title', variants: ['titleL', 'titleM', 'titleS', 'titleXS'], sample: 'Your next chapter' },
  {
    name: 'Body',
    variants: ['bodyLStandard', 'bodyMStandard', 'bodySStandard', 'bodyMCompact', 'bodySCompact'],
    sample: 'Everything you need to know, clearly in one place.',
  },
  { name: 'Label', variants: ['labelM', 'labelS'], sample: 'Next step' },
  { name: 'Metric', variants: ['metricL', 'metricM', 'metricS'], sample: '$825,000' },
]

const semanticColorGroups = [
  {
    name: 'Text',
    tokens: [
      'text-lightest', 'text-light', 'text-disabled', 'text-primary', 'text-dark',
      'text-on-color-primary', 'text-on-color-light', 'text-caution', 'text-error', 'text-success',
    ],
  },
  {
    name: 'Surface',
    tokens: [
      'surface-glass', 'surface-primary', 'surface-primary-disabled', 'surface-primary-dark',
      'surface-primary-darkest', 'surface-secondary', 'surface-secondary-disabled',
      'surface-secondary-dark', 'surface-secondary-darkest', 'surface-reverse-primary',
      'surface-reverse-secondary',
    ],
  },
  {
    name: 'Stroke',
    tokens: [
      'stroke-primary-light', 'stroke-primary-lightest', 'stroke-primary',
      'stroke-primary-dark', 'stroke-primary-darkest',
    ],
  },
] as const

const primitiveColorFamilies = ['neutral', 'gray', 'blue', 'sky', 'green', 'yellow', 'red', 'violet'] as const
const primitiveColorSteps = ['50', '100', '200', '300', '400', '500', '600', '700', '800', '900'] as const
const neutralColorSteps = [...primitiveColorSteps, '950'] as const
const baseColorTokens = ['base-black', 'base-white'] as const

function Section({
  id,
  number,
  title,
  description,
  source,
  kind = 'Component',
  children,
}: {
  id: string
  number: string
  title: string
  description: string
  source: string
  kind?: 'Foundation' | 'Component'
  children: ReactNode
}) {
  return (
    <Box component="section" id={id} aria-labelledby={`${id}-title`} sx={{ scrollMarginTop: 32, py: { xs: 5, md: 7 }, borderTop: 1, borderColor: 'divider' }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="labelS" color="text.secondary" sx={{ display: 'block', mb: 1.5, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          {number} / {kind}
        </Typography>
        <Typography component="h2" id={`${id}-title`} variant="titleL" sx={{ mb: 1 }}>
          {title}
        </Typography>
        <Typography variant="bodyMStandard" color="text.secondary" sx={{ maxWidth: 680, textWrap: 'pretty' }}>
          {description}
        </Typography>
        <Typography variant="labelS" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
          {source}
        </Typography>
      </Box>
      {children}
    </Box>
  )
}

function Specimen({ label, children }: { label: string; children: ReactNode }) {
  return (
    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'minmax(0, 1fr) minmax(0, 1fr)' }, alignItems: 'center', gap: { xs: 1.5, sm: 3 }, minWidth: 0 }}>
      <Typography variant="labelM" color="text.secondary">{label}</Typography>
      <Box sx={{ width: '100%', minWidth: 0, minHeight: 96, display: 'flex', alignItems: 'center', justifyContent: 'center', px: 2, py: 2.5, bgcolor: 'var(--color-semantic-surface-secondary)', borderRadius: 2 }}>
        {children}
      </Box>
    </Box>
  )
}

function SpecimenList({ children }: { children: ReactNode }) {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {children}
    </Box>
  )
}

const buttonVariants: Array<{ label: string; variant: ButtonProps['variant']; onImage?: boolean }> = [
  { label: 'Primary / contained', variant: 'contained' },
  { label: 'Secondary / outlined', variant: 'outlined' },
  { label: 'Quiet / text', variant: 'text' },
  { label: 'On Image Primary', variant: 'onImagePrimary', onImage: true },
  { label: 'On Image Secondary', variant: 'onImageSecondary', onImage: true },
]

function ButtonSection() {
  const [clicks, setClicks] = useState(0)
  const tryAction = () => setClicks(value => value + 1)

  return (
    <Section id="button" number="03" title="Button"
      description="Five shared variants use the PLACE pill radius, typography, padding, and 44px minimum height. Photo actions use the same variants here and in the listing header."
      source="Theme: MuiButton · src/theme.ts · src/mui.d.ts">
      <Typography component="h3" variant="titleXS" sx={{ mb: 2 }}>Variants and states</Typography>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mb: 3 }}>
        Each row shows an enabled, disabled, and loading button. Hover, press, or use Tab to inspect the actual interaction styles on enabled samples. These are live components, without simulated state overrides. Pressing scales a button down to 98% and fills it with a light gray ripple (a step darker than hover, never heavy). The same press feel applies to icon buttons, tabs, and menu items.
      </Typography>
      <SpecimenList>
        {buttonVariants.map(({ label, variant, onImage }) => (
          <Specimen key={label} label={label}>
            <Box sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1.5, flexWrap: 'wrap', p: 2, borderRadius: 2,
              ...(onImage ? { backgroundImage: `linear-gradient(rgb(0 0 0 / 32%), rgb(0 0 0 / 32%)), url("${sampleSellerTransaction.listing.photoUrl}")`, backgroundSize: 'cover', backgroundPosition: 'center', minHeight: 160 } : {}) }}>
              <Button variant={variant} onClick={tryAction}>{variant === 'onImageSecondary' ? 'Copy link' : onImage ? 'See Listing' : 'Continue'}</Button>
              <Button variant={variant} disabled>Disabled</Button>
              <Button variant={variant} loading>Loading</Button>
            </Box>
          </Specimen>
        ))}
        <Specimen label="Photo action pairing">
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', justifyContent: 'center', width: '100%', p: 3, borderRadius: 2, backgroundImage: `linear-gradient(rgb(0 0 0 / 32%), rgb(0 0 0 / 32%)), url("${sampleSellerTransaction.listing.photoUrl}")`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
            <Button variant="onImageSecondary" endIcon={<ContentCopyOutlined aria-hidden="true" />} onClick={tryAction}>Copy link</Button>
            <Button variant="onImagePrimary" endIcon={<ArrowOutwardOutlined />} onClick={tryAction}>See Listing</Button>
          </Box>
        </Specimen>
        <Specimen label="Listing outlined / contextual treatment">
          <Button variant="outlined" className="listing-copy-link" onClick={tryAction}>Copy link</Button>
        </Specimen>
        <Specimen label="Card action / CardActionButton">
          <Paper variant="outlined" sx={{ width: '100%', p: { xs: 2, sm: 3 } }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 2 }}>
              <Typography variant="titleS">Recent activity</Typography>
              <CardActionButton onClick={tryAction}>See all</CardActionButton>
            </Box>
          </Paper>
        </Specimen>
        <Specimen label="Sizes / small, medium, large">
          <Stack direction="row" spacing={2} useFlexGap sx={{ flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center' }}>
            {([{ size: 'small', height: 44 }, { size: 'medium', height: 48 }, { size: 'large', height: 56 }] as const).map(({ size, height }) => (
              <Stack key={size} spacing={1} sx={{ alignItems: 'center' }}>
                <Button size={size} variant="outlined" onClick={tryAction}>Continue</Button>
                <Typography variant="labelS" color="text.secondary">{size} · {height}px</Typography>
              </Stack>
            ))}
          </Stack>
        </Specimen>
        <Specimen label="Leading and trailing icons">
          <Stack direction="row" spacing={1} useFlexGap sx={{ flexWrap: 'wrap' }}>
            <Button variant="outlined" startIcon={<DescriptionOutlined />} onClick={tryAction}>Documents</Button>
            <Button variant="contained" endIcon={<ArrowOutwardOutlined />} onClick={tryAction}>See Listing</Button>
          </Stack>
        </Specimen>
      </SpecimenList>
      <Typography aria-live="polite" variant="labelS" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
        {clicks > 0 ? `Sample action used ${clicks} ${clicks === 1 ? 'time' : 'times'}.` : 'Select an enabled button to try it.'}
      </Typography>
    </Section>
  )
}

function ChipSection() {
  const [selected, setSelected] = useState(false)
  return (
    <Section id="chip" number="05" title="Chip"
      description="Chip variants share PLACE small-label typography. PortalOutlineTag is a separate 30px outlined treatment used for publication and task due dates."
      source="Theme: MuiChip · PortalOutlineTag">
      <SpecimenList>
        <Specimen label="Filled / medium"><Chip label="In progress" /></Specimen>
        <Specimen label="Outlined / medium"><Chip label="In progress" variant="outlined" /></Specimen>
        <Specimen label="Small / filled and outlined"><Stack direction="row" spacing={1}><Chip label="In progress" size="small" /><Chip label="In progress" size="small" variant="outlined" /></Stack></Specimen>
        <Specimen label="Portal outlined / publication and due date"><Stack direction="row" spacing={1} useFlexGap sx={{ flexWrap: 'wrap' }}><PortalOutlineTag label="Published" /><PortalOutlineTag label="Due 10/08/2026" /></Stack></Specimen>
        <Specimen label="Clickable / live interaction">
          <Chip label={selected ? 'Selected' : 'Filter'} variant="outlined" clickable aria-pressed={selected} onClick={() => setSelected(value => !value)} />
        </Specimen>
        <Specimen label="Disabled / filled and outlined"><Stack direction="row" spacing={1}><Chip label="Filter" disabled /><Chip label="Filter" variant="outlined" disabled /></Stack></Specimen>
      </SpecimenList>
    </Section>
  )
}

function SegmentedSwitchSection() {
  const [audience, setAudience] = useState<'seller' | 'buyer'>('seller')
  const audienceOptions: readonly SegmentedSwitchOption<'seller' | 'buyer'>[] = [
    { value: 'seller', label: 'Seller' },
    { value: 'buyer', label: 'Buyer' },
  ]
  const viewOptions: readonly SegmentedSwitchOption<'list' | 'map'>[] = [
    { value: 'list', label: 'List' },
    { value: 'map', label: 'Map' },
  ]

  return (
    <Section
      id="segmented-switch"
      number="06"
      title="Segmented switch"
      description="A compact control for moving between a few parallel views within the same page."
      source="SegmentedSwitch · src/components/SegmentedSwitch.tsx"
    >
      <SpecimenList>
        <Specimen label="Default / M">
          <SegmentedSwitch options={audienceOptions} value={audience} onChange={setAudience} aria-label="Client view" />
        </Specimen>
        <Specimen label="Compact / S">
          <SegmentedSwitch options={viewOptions} defaultValue="list" size="s" aria-label="Search view" />
        </Specimen>
        <Specimen label="One option disabled">
          <SegmentedSwitch options={[{ value: 'list', label: 'List' }, { value: 'map', label: 'Map', disabled: true }]} defaultValue="list" aria-label="Search view with unavailable map" />
        </Specimen>
        <Specimen label="Disabled">
          <SegmentedSwitch options={audienceOptions} defaultValue="seller" disabled aria-label="Unavailable client view" />
        </Specimen>
      </SpecimenList>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
        Use for two or three related views, not page navigation. The selected option is pressed; inactive options gain a quiet hover fill and every option has a visible keyboard focus state.
      </Typography>
    </Section>
  )
}

function IconButtonSection() {
  const states = ['Default', 'Hover', 'Focus', 'Pinned', 'Disabled'] as const

  return (
    <Section
      id="icon-button"
      number="04"
      title="Icon button"
      description="Quiet icon buttons keep secondary actions available without competing with primary actions."
      source="PlaceIconButton · shared PLACE icon control"
    >
      <SpecimenList>
        {states.map((label) => (
          <Specimen key={label} label={label}>
            <PlaceIconButton
              aria-label={label === 'Pinned' ? 'Unpin document' : 'Call agent'}
              title={label === 'Pinned' ? 'Unpin document' : 'Call agent'}
              data-state={label.toLowerCase()}
              aria-pressed={label === 'Pinned' ? true : undefined}
              disabled={label === 'Disabled'}
            >
              {label === 'Pinned' ? <PushPin fontSize="small" /> : <PhoneOutlined fontSize="small" />}
            </PlaceIconButton>
          </Specimen>
        ))}
      </SpecimenList>
    </Section>
  )
}

function PaperSection() {
  return (
    <Section
      id="paper"
      number="07"
      title="Paper"
      description="Paper provides the quiet surface behind grouped content. The outlined variant uses the system hairline border."
      source="Theme: MuiPaper · src/theme.ts"
    >
      <SpecimenList>
        <Specimen label="Default / flat">
          <Paper elevation={0} sx={{ width: '100%', p: 4 }}>
            <Typography variant="titleXS" sx={{ display: 'block' }}>Transaction summary</Typography>
            <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ display: 'block', mt: 1 }}>A calm surface for related information.</Typography>
          </Paper>
        </Specimen>
        <Specimen label="Outlined">
          <Paper variant="outlined" sx={{ width: '100%', p: 4 }}>
            <Typography variant="titleXS" sx={{ display: 'block' }}>Transaction summary</Typography>
            <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ display: 'block', mt: 1 }}>A hairline marks the surface boundary.</Typography>
          </Paper>
        </Specimen>
      </SpecimenList>
      <Typography variant="labelS" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
        Paper is a container; hover, pressed, and disabled states are not part of its theme skin.
      </Typography>
    </Section>
  )
}

function ModalSection() {
  const [minimal, setMinimal] = useState(false)
  const [activeSize, setActiveSize] = useState<PlaceModalSize | null>(null)

  return (
    <Section
      id="modal"
      number="08"
      title="Modal"
      description="A focused overlay built on MUI Dialog, with five predictable widths and one consistent PLACE surface."
      source="PlaceModal · src/components/PlaceModal.tsx"
    >
      <SpecimenList>
        {modalSizes.map(size => (
          <Specimen key={size} label={`${size.toUpperCase()} / ${placeModalWidths[size]}px`}>
            <Button variant="outlined" onClick={() => { setMinimal(false); setActiveSize(size) }}>Open modal</Button>
          </Specimen>
        ))}
        <Specimen label="Content only / no description or footer actions">
          <Button variant="outlined" onClick={() => { setMinimal(true); setActiveSize('s') }}>Open content-only modal</Button>
        </Specimen>
      </SpecimenList>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mt: 2 }}>All five sizes share the same header, close control, and surface. Description and footer actions are optional content slots. Use Escape, the backdrop, or the close button to dismiss the sample.</Typography>
      <PlaceModal
        open={activeSize !== null}
        onClose={() => setActiveSize(null)}
        size={activeSize ?? 'm'}
        title="Transaction update"
        description={minimal ? undefined : 'A focused place for details that need your attention.'}
        actions={minimal ? undefined : (
          <>
            <Button variant="text" onClick={() => setActiveSize(null)}>Cancel</Button>
            <Button variant="contained" onClick={() => setActiveSize(null)}>Done</Button>
          </>
        )}
      >
        <Typography variant="bodyMStandard" color="text.secondary">
          Your team has shared a new update. Review the details here, then return to your transaction when you’re ready.
        </Typography>
      </PlaceModal>
    </Section>
  )
}

function SheetSection() {
  const [open, setOpen] = useState(false)
  return (
    <Section id="sheet" number="09" title="Sheet" description="PlaceSheet is the shared bottom-sheet surface used by listing details, resource guides, the marketing dashboard, and transaction dates. It has one responsive width, rather than the five modal sizes. Narrow content, such as transaction dates, sits in a centered 720px reading column inside the sheet." source="PlaceSheet · src/components/PlaceSheet.tsx · src/components/place-sheet.css">
      <Specimen label="Default / responsive bottom sheet"><Button variant="outlined" onClick={() => setOpen(true)}>Open sheet</Button></Specimen>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mt: 2 }}>The sheet uses the shared rounded top corners, scrim, and scrolling surface. Escape, the backdrop, or the close control dismiss it and return focus to its trigger. Reduced motion removes the opening transition.</Typography>
      <PlaceSheet open={open} onClose={() => setOpen(false)} label="Sheet preview">
        <Box sx={{ p: { xs: 3, sm: 4 } }}>
          <Stack direction="row" sx={{ alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
            <Typography component="h2" variant="titleS">Sheet preview</Typography>
            <PlaceIconButton aria-label="Close sheet preview" onClick={() => setOpen(false)}><CloseOutlined /></PlaceIconButton>
          </Stack>
          <Typography variant="bodyMStandard" sx={{ mt: 3 }}>Use this surface for detailed reading while keeping the transaction behind it. Listing and resource sheets add their own content to this shared component.</Typography>
        </Box>
      </PlaceSheet>
    </Section>
  )
}

function FormControlsSection() {
  const [name, setName] = useState('Deposit due')
  const [status, setStatus] = useState('Published')
  const [tags, setTags] = useState<string[]>(['Earnest money guide'])
  const [checked, setChecked] = useState(true)
  const [choice, setChoice] = useState('first-party')
  const [on, setOn] = useState(true)
  return (
    <Section
      id="form-controls"
      number="12"
      title="Form controls"
      description="Every text field, select, autocomplete, checkbox, radio, and switch takes its PLACE styling from the theme, so plain MUI components are already on brand. Labels sit above the field in labelM, never floating inside the border. Fields are 48px tall (44px with size small) with a 12px radius and a stroke-primary border; hover darkens the border, and focus switches it to text-dark with a soft 3px ring. Helper and error text sit 6px below in labelS. Input text stays 16px, so phones never zoom in."
      source="MuiTextField, MuiInputLabel, MuiOutlinedInput, MuiFormHelperText, MuiSelect, MuiAutocomplete, MuiCheckbox, MuiRadio, MuiSwitch · src/theme.ts · src/components/controlIcons.tsx"
    >
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, minmax(0, 1fr))' }, gap: 3, maxWidth: 840 }}>
        <TextField label="Title" value={name} onChange={event => setName(event.target.value)} helperText="Shown under the date in the client’s list." fullWidth />
        <TextField label="Email" placeholder="name@example.com" required fullWidth />
        <TextField label="Date" type="date" defaultValue="2026-10-05" fullWidth />
        <TextField label="Contact details" value="tim@example.com" disabled helperText="Disabled: details come from Brivity." fullWidth />
        <TextField label="Email" value="tim@" error helperText="Enter a full email address." fullWidth />
        <TextField label="Search team resources" size="small" fullWidth />
        <FormControl fullWidth><InputLabel id="gallery-form-select">Show</InputLabel><Select labelId="gallery-form-select" label="Show" value={status} onChange={event => setStatus(event.target.value)}>{['All resources', 'Published', 'Drafts', 'Archived'].map(option => <MenuItem key={option} value={option}>{option}</MenuItem>)}</Select></FormControl>
        <Autocomplete multiple options={['Earnest money guide', 'Appraisal guide', 'Closing day guide']} value={tags} onChange={(_, value) => setTags(value)} renderInput={params => <TextField {...params} label="Attached resources" />} />
        <TextField label="Personal note" multiline minRows={3} placeholder="A few words for your client…" fullWidth sx={{ gridColumn: { md: '1 / -1' } }} />
      </Box>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mt: 4, mb: 1 }}>Checkboxes and radios are 20px drawn marks: a 6px-radius square or a circle with a 1.5px stroke-primary-dark border, filled with the reverse surface when selected. They keep a 44px hit area, skip the ripple, and show a 2px ring on keyboard focus. The switch is a 44 × 24 pill with the thumb inside the track, dark when on.</Typography>
      <SpecimenList>
        <Specimen label="Checkbox"><FormControlLabel control={<Checkbox checked={checked} onChange={event => setChecked(event.target.checked)} />} label="Also show it to clients" /></Specimen>
        <Specimen label="Checkbox / disabled"><FormControlLabel control={<Checkbox disabled />} label="Unavailable" /><FormControlLabel control={<Checkbox disabled checked />} label="Locked on" /></Specimen>
        <Specimen label="Radio group"><RadioGroup value={choice} onChange={event => setChoice(event.target.value)}><FormControlLabel value="first-party" control={<Radio />} label="First Party" /><FormControlLabel value="idx" control={<Radio />} label="IDX MVP" /></RadioGroup></Specimen>
        <Specimen label="Switch"><Switch checked={on} onChange={event => setOn(event.target.checked)} slotProps={{ input: { 'aria-label': 'Visible to clients' } }} /><Switch disabled slotProps={{ input: { 'aria-label': 'Disabled switch' } }} /></Specimen>
      </SpecimenList>
    </Section>
  )
}

function MenuSection() {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null)
  const [status, setStatus] = useState('All resources')
  return (
    <Section id="menu" number="11" title="Menu" description="The PLACE menu styles every overflow (···) menu and Select dropdown: rounded 12px surface, light stroke, document shadow, labelM items with an 8px hover fill. Destructive items add the is-destructive class and always open a confirmation dialog." source="MuiMenu, MuiMenuItem, MuiListItemIcon · src/theme.ts">
      <SpecimenList>
        <Specimen label="Overflow menu"><IconButton aria-label="More actions" aria-haspopup="menu" onClick={event => setAnchor(event.currentTarget)}><MoreHorizOutlined /></IconButton>
          <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} transformOrigin={{ vertical: 'top', horizontal: 'right' }}>
            <MenuItem onClick={() => setAnchor(null)}><ListItemIcon><EditOutlined /></ListItemIcon><ListItemText>Edit</ListItemText></MenuItem>
            <MenuItem onClick={() => setAnchor(null)}><ListItemIcon><ArchiveOutlined /></ListItemIcon><ListItemText>Archive</ListItemText></MenuItem>
            <MenuItem className="is-destructive" onClick={() => setAnchor(null)}><ListItemIcon><DeleteOutlineOutlined /></ListItemIcon><ListItemText>Delete</ListItemText></MenuItem>
          </Menu>
        </Specimen>
        <Specimen label="Select dropdown"><FormControl size="small" sx={{ minWidth: 200 }}><InputLabel id="gallery-menu-select">Show</InputLabel><Select labelId="gallery-menu-select" label="Show" value={status} onChange={event => setStatus(event.target.value)}>{['All resources', 'Published', 'Drafts', 'Archived'].map(value => <MenuItem key={value} value={value}>{value}</MenuItem>)}</Select></FormControl></Specimen>
      </SpecimenList>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mt: 2 }}>Use a menu only for two or more actions. A single action, like removing someone’s portal access, should be a visible button instead.</Typography>
    </Section>
  )
}

function ToastSection() {
  return (
    <Section id="toast" number="10" title="Toast" description="One shared Sonner toaster appears at the top center with a dark neutral background and light text." source="PlaceToaster · src/components/PlaceToaster.tsx">
      <SpecimenList>
        <Specimen label="Success"><Button variant="outlined" onClick={() => toast.success('Listing link copied')}>Preview success</Button></Specimen>
        <Specimen label="Error"><Button variant="outlined" onClick={() => toast.error('Couldn’t copy the link. Please try again.')}>Preview error</Button></Specimen>
        <Specimen label="Informational"><Button variant="outlined" onClick={() => toast('Your team shared an update')}>Preview message</Button></Specimen>
      </SpecimenList>
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mt: 2 }}>These buttons trigger the production toaster. Toasts announce the result without moving focus, and show a close (x) button on hover or keyboard focus; reduced motion removes transitions. Success and error use distinct icons on the same neutral surface.</Typography>
    </Section>
  )
}

function TypographySection() {
  return (
    <Section
      id="typography"
      number="01"
      title="Typography"
      description="Seventeen Manrope roles are available as named MUI Typography variants. Each sample below renders with the actual token."
      source="Tokens: src/design-tokens.ts · src/mui.d.ts"
      kind="Foundation"
    >
      <Stack spacing={4}>
        {typographyGroups.map(group => (
          <Box key={group.name}>
            <Typography component="h3" variant="titleXS" sx={{ mb: 1.5 }}>{group.name}</Typography>
            <Box sx={{ borderTop: 1, borderColor: 'divider' }}>
              {group.variants.map(variant => (
                <Box key={variant} sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '170px minmax(0, 1fr)' }, gap: { xs: 1, md: 3 }, alignItems: 'baseline', py: 2.5, borderBottom: 1, borderColor: 'divider' }}>
                  <Typography variant="labelS" color="text.secondary" component="span">{variant}</Typography>
                  <Typography variant={variant} component="p" sx={{ m: 0, overflowWrap: 'anywhere' }}>{group.sample}</Typography>
                </Box>
              ))}
            </Box>
          </Box>
        ))}
      </Stack>
    </Section>
  )
}

function primitiveReference(variable: string, value: string, styles: CSSStyleDeclaration) {
  if (variable === '--color-semantic-surface-glass') {
    return document.documentElement.dataset.colorMode === 'goth' ? 'neutral-900 / 94%' : 'base-white / 94%'
  }

  for (const family of primitiveColorFamilies) {
    for (const step of family === 'neutral' ? neutralColorSteps : primitiveColorSteps) {
      if (styles.getPropertyValue(`--color-primitive-${family}-${step}`).trim() === value) return `${family}-${step}`
    }
  }

  for (const token of baseColorTokens) {
    if (styles.getPropertyValue(`--color-primitive-${token}`).trim() === value) return token
  }

  return 'Custom color'
}

function ColorToken({ variable, label, showValue = true, showPrimitiveReference = false }: { variable: string; label: string; showValue?: boolean; showPrimitiveReference?: boolean }) {
  const styles = typeof window === 'undefined' ? null : getComputedStyle(document.documentElement)
  const value = styles?.getPropertyValue(variable).trim() || `var(${variable})`
  const detail = showPrimitiveReference && styles ? primitiveReference(variable, value, styles) : value

  return (
    <Box sx={{ minWidth: 0 }}>
      <Box aria-hidden="true" sx={{ height: 48, bgcolor: `var(${variable})`, border: 1, borderColor: 'divider', borderRadius: 1 }} />
      <Typography component="p" variant="labelS" sx={{ mt: 1, mb: 0, overflowWrap: 'anywhere' }}>{label}</Typography>
      {showValue && <Typography component="p" variant="labelS" color="text.secondary" sx={{ mt: 0.5, mb: 0, overflowWrap: 'anywhere' }}>{detail}</Typography>}
    </Box>
  )
}

function ColorsSection() {
  return (
    <Section
      id="colors"
      number="02"
      title="Colors"
      description="PLACE color tokens pair semantic roles with a compact set of primitive scales. Semantic swatches show their primitive reference in the current color mode."
      source="Tokens: src/design-tokens.css · Light and Goth modes"
      kind="Foundation"
    >
      <Typography component="h3" variant="titleXS" sx={{ mb: 2 }}>Semantic colors</Typography>
      <Stack spacing={4}>
        {semanticColorGroups.map(group => (
          <Box key={group.name}>
            <Typography component="h4" variant="titleXS" sx={{ mb: 1.5 }}>{group.name}</Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 150px), 1fr))', gap: 2 }}>
              {group.tokens.map(token => (
                <ColorToken key={token} label={token} variable={`--color-semantic-${token}`} showPrimitiveReference />
              ))}
            </Box>
          </Box>
        ))}
      </Stack>

      <Typography component="h3" variant="titleXS" sx={{ mt: 6, mb: 1 }}>Primitive palettes</Typography>
      <Typography variant="bodySStandard" color="text.secondary" component="p" sx={{ mb: 3 }}>
        Neutral, brand, and status scales available to build semantic roles.
      </Typography>
      <Stack spacing={3}>
        {primitiveColorFamilies.map(family => (
          <Box key={family}>
            <Typography component="h4" variant="titleXS" sx={{ mb: 1.5, textTransform: 'capitalize' }}>{family}</Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 54px), 1fr))', gap: 1 }}>
              {(family === 'neutral' ? neutralColorSteps : primitiveColorSteps).map(step => {
                const token = `--color-primitive-${family}-${step}`
                return <ColorToken key={token} label={step} variable={token} showValue={false} />
              })}
            </Box>
          </Box>
        ))}
        <Box>
          <Typography component="h4" variant="titleXS" sx={{ mb: 1.5 }}>Base</Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 150px), 1fr))', gap: 2 }}>
            {baseColorTokens.map(token => (
              <ColorToken key={token} label={token} variable={`--color-primitive-${token}`} showValue={false} />
            ))}
          </Box>
        </Box>
      </Stack>
    </Section>
  )
}

function ListingSheetSection() {
  const [open, setOpen] = useState(false)
  const { listing } = sampleSellerTransaction

  return (
    <Section
      id="listing-sheet"
      number="16"
      title="Listing sheet"
      description="A centered listing sheet with a photo grid, full photo feed, structured home details, and an interactive location map."
      source="Seller portal · ListingDetailsSheet"
    >
      <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
        The MLS number sits above the address with standard label spacing. Status, publication, and source tags sit 12px below the price. The description fills the available width and sits 8px below its heading. Highlight labels use the medium size, while Financial details and Listing information share a row above the map on wide screens. The agent footer uses horizontal dividers like the main portal footer.
      </Typography>
      <Box sx={{ maxWidth: 640, overflow: 'hidden', borderRadius: '32px 32px 0 0', bgcolor: 'background.paper', boxShadow: 'var(--elevation-raised)' }}>
        <Box sx={{ height: 230, display: 'grid', gridTemplateColumns: '2fr 1fr', gridTemplateRows: 'repeat(2, minmax(0, 1fr))', gap: 1, overflow: 'hidden' }}>
          {listing.photos.slice(0, 3).map((photo, index) => (
            <Box
              component="img"
              key={photo.url}
              src={photo.url}
              alt={photo.alt}
              sx={{ width: '100%', height: '100%', display: 'block', objectFit: 'cover', gridRow: index === 0 ? 'span 2' : undefined }}
            />
          ))}
        </Box>
        <Box sx={{ p: 3, display: 'flex', alignItems: { xs: 'flex-start', sm: 'center' }, justifyContent: 'space-between', flexDirection: { xs: 'column', sm: 'row' }, gap: 2 }}>
          <Box>
            <Typography variant="labelS" color="text.secondary">MLS # {sampleSellerTransaction.details.listingFacts.find(({ label }) => label === 'MLS #')?.value}</Typography>
            <Typography variant="titleS">{listing.address}</Typography>
            <Typography variant="bodySStandard" color="text.secondary">{listing.city}, {listing.state} · {listing.photos.length} photos</Typography>
            <Chip size="small" label={`Source: ${listing.dataSource}`} variant="outlined" sx={{ mt: 1 }} />
          </Box>
          <Button variant="contained" onClick={() => setOpen(true)}>Preview sheet</Button>
        </Box>
      </Box>
      <ListingDetailsSheet open={open} onClose={() => setOpen(false)} transaction={sampleSellerTransaction} />
    </Section>
  )
}

function EyebrowSection() {
  return (
    <Section id="eyebrow" number="13" title="Eyebrow" description="The small uppercase label that sits above a title." source="Eyebrow · src/components/Eyebrow.tsx · src/components/eyebrow.css">
              <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mb: 2 }}>Eyebrow is the small uppercase label above a title: labelS, uppercase, 0.08em tracking, and the text-primary color. Use it for “Seller transaction”, “Your home”, MLS numbers, and guide labels. Contexts may change its color, such as text-light on the property card. The centered timeline eyebrow keeps a wider 0.16em tracking because it sits over a full-bleed tracker.</Typography>
              <Stack spacing={1}>
                <Eyebrow>Seller transaction</Eyebrow>
                <Eyebrow>MLS # 00001428</Eyebrow>
              </Stack>
    </Section>
  )
}

function StatSection() {
  return (
    <Section id="stat" number="14" title="Stat" description="Numbers with a label: a headline figure for a card and smaller supporting figures." source="Stat, HeadlineStat · src/components/Stat.tsx · src/components/stat.css">
              <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mb: 2 }}>HeadlineStat leads a card: a labelM label, a displayL number, and optional context. Stat is the supporting number: metricM with a bodyS label directly below. Numbers use tabular figures so columns line up. The listing views snapshot and the marketing dashboard both use these.</Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={6} sx={{ alignItems: { sm: 'flex-end' } }}>
                <HeadlineStat label="Total listing views" value="8,746" context="Across listing sites" />
                <Stat value="2,378" label="Unique visitors" />
                <Stat value="42" label="Saves" />
              </Stack>
    </Section>
  )
}

function FactListSection() {
  return (
    <Section id="fact-list" number="15" title="Fact list" description="Label and value pairs, in a grid or in rows." source="FactList · src/components/FactList.tsx · src/components/fact-list.css">
              <Typography component="p" variant="bodySStandard" color="text.secondary" sx={{ mb: 2 }}>FactList shows label and value pairs. The grid layout stacks a labelS label over a labelM value in two columns; the property card and timeline item modal use it. The rows layout puts a bodyS label on the left and the value on the right, one pair per line; listing details use it, with an optional second column that collapses below 760px. Parents set spacing and surfaces with their own class.</Typography>
              <Stack spacing={4} sx={{ maxWidth: 560 }}>
                <FactList facts={[{ label: 'Status', value: 'Under contract' }, { label: 'MLS number', value: '00001428' }]} />
                <FactList layout="rows" facts={[{ label: 'Property type', value: 'Single-family home' }, { label: 'Year built', value: '2003' }, { label: 'Square feet', value: '3,952 sq ft' }]} />
              </Stack>
    </Section>
  )
}

export function ComponentGallery() {
  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <Box component="header" sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Container maxWidth="lg" sx={{ minHeight: 72, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
          <Typography variant="titleS">PLACE</Typography>
          <Button component="a" href="/" variant="text" color="primary" startIcon={<ArrowBackOutlined />} sx={{ px: 1 }}>
            Sandbox home
          </Button>
        </Container>
      </Box>

      <Container component="main" maxWidth="lg" sx={{ pt: { xs: 7, md: 10 }, pb: 12 }}>
        <Typography variant="labelS" color="text.secondary" sx={{ textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Design system / 01
        </Typography>
        <Typography component="h1" variant="displayS" sx={{ mt: 1.5, textWrap: 'balance' }}>Component gallery</Typography>
        <Typography component="p" variant="bodyMStandard" color="text.secondary" sx={{ mt: 2, mb: { xs: 7, md: 10 }, maxWidth: 650, textWrap: 'pretty' }}>
          A working record of PLACE foundations and system-wide components. Samples render the production components and their supported variants. Page-specific components live with their pages, not here.
        </Typography>

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '170px minmax(0, 1fr)' }, gap: { xs: 2, md: 7 } }}>
          <Box component="nav" aria-label="Gallery sections" sx={{ alignSelf: 'start', position: { md: 'sticky' }, top: { md: 32 }, display: 'flex', flexDirection: { xs: 'row', md: 'column' }, gap: { xs: 2, md: 1 }, overflowX: { xs: 'auto', md: 'visible' }, pb: { xs: 2, md: 0 } }}>
            <Typography variant="labelS" color="text.secondary" sx={{ display: { xs: 'none', md: 'block' }, mb: 1, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              Library / {sections.length}
            </Typography>
            {sections.map(section => (
              <Box key={section.id} component="a" href={`#${section.id}`} sx={{ flexShrink: 0, color: 'text.primary', textDecoration: 'none', py: 0.75, borderRadius: 1, typography: 'labelM', transition: 'color 150ms ease', '&:hover': { color: 'text.secondary' }, '&:focus-visible': { outline: '2px solid var(--color-semantic-stroke-primary-dark)', outlineOffset: 3 } }}>
                {section.name}
              </Box>
            ))}
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <TypographySection />
            <ColorsSection />
            <ButtonSection />
            <IconButtonSection />
            <ChipSection />
            <SegmentedSwitchSection />
            <PaperSection />
            <ModalSection />
            <SheetSection />
            <ToastSection />
            <MenuSection />
            <FormControlsSection />
            <EyebrowSection />
            <StatSection />
            <FactListSection />
            <ListingSheetSection />
            <Section
              id="email-blocks"
              number="17"
              title="Email blocks"
              description="The client email family shares a team and brokerage header, property context, body pane, primary action, agent signature, and a centered footer."
              source="src/email-templates/EmailPreview.tsx · src/email-templates/email-preview.css"
            >
              <Box sx={{ maxWidth: 640, mx: 'auto', bgcolor: 'var(--color-semantic-surface-secondary)', p: { xs: 1, sm: 3 } }}>
                <EmailPreview template={emailTemplates[0]} />
              </Box>
              <Button component="a" href="/email-templates" variant="text" sx={{ mt: 3 }}>Review all email templates</Button>
            </Section>
          </Box>
        </Box>
      </Container>
    </Box>
  )
}
