import { Avatar, Box, Container, Stack, Typography } from '@mui/material'
import { brandAssets } from '../../assets/brand'
import type { TransactionViewer } from '../types'
import './portal-topbar.css'

/** PLACE wordmark with “Client portal” on the left, the signed-in client on the right. */
export function PortalTopbar({ viewer }: { viewer?: Pick<TransactionViewer, 'name' | 'role' | 'initials'> }) {
  return (
    <Box component="header" className="portal-topbar">
      <Container maxWidth="xl" className="portal-topbar-inner">
        <Box component="a" href="/" className="portal-brand-link" aria-label="PLACE client portal home">
          <Stack direction="row" spacing={1.5} sx={{ alignItems: 'center' }}>
            <Box component="img" src={brandAssets.place.wordmarkDefault} alt="" className="place-wordmark" />
            <Box className="topbar-divider" />
            <Typography variant="bodySStandard" color="text.secondary" className="portal-brand-label">Client portal</Typography>
          </Stack>
        </Box>
        {viewer && (
          <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
            <Avatar className="account-avatar">{viewer.initials}</Avatar>
            <Box className="account-name">
              <Typography variant="labelM">{viewer.name}</Typography>
              <Typography variant="labelS" color="text.secondary">{viewer.role}</Typography>
            </Box>
          </Stack>
        )}
      </Container>
    </Box>
  )
}
