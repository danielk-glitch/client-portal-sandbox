/**
 * Document viewer · full-screen reader for one shared document.
 * - Top bar: the document's name and file name, page position and zoom, then Download, Pin, Details, a divider, and Close.
 * - Center: every page of the real PDF on a soft gray stage (pdf.js via react-pdf, loaded on first open).
 * - Right: a Details panel with what the document is and where it came from. Open by default on wide
 *   screens; on phones it slides over the pages and Details toggles it.
 * - States: loading (page placeholder), and error or missing file (explains; Download in the bar still works).
 * Keyboard: Esc closes, + and - zoom, 0 fits the page to the width.
 */
import { lazy, Suspense, useCallback, useEffect, useLayoutEffect, useState, type ReactNode } from 'react'
import { Box, Button, Dialog, Tooltip, Typography, useMediaQuery } from '@mui/material'
import AddRounded from '@mui/icons-material/AddRounded'
import CloseOutlined from '@mui/icons-material/CloseOutlined'
import DescriptionOutlined from '@mui/icons-material/DescriptionOutlined'
import FileDownloadOutlined from '@mui/icons-material/FileDownloadOutlined'
import InfoOutlined from '@mui/icons-material/InfoOutlined'
import PushPin from '@mui/icons-material/PushPin'
import PushPinOutlined from '@mui/icons-material/PushPinOutlined'
import RemoveRounded from '@mui/icons-material/RemoveRounded'
import { toast } from 'sonner'
import { FactList, type Fact } from '../../components/FactList'
import { PlaceIconButton } from '../../components/PlaceIconButton'
import type { TransactionDocument } from '../types'
import type { PdfInfo } from './PdfPages'
import './document-viewer.css'

const PdfPages = lazy(() => import('./PdfPages'))

const ZOOM_STEPS = [0.5, 0.75, 1, 1.25, 1.5, 2]
/** Pages never draw wider than a real letter page at 100%, even on big screens. */
const MAX_FIT_WIDTH = 816

export type ViewerDocument = TransactionDocument & {
  /** The uploaded file's name. Falls back to the document's category. */
  fileName?: string
  /** Where the PDF lives. Defaults to /documents/<id>.pdf (prototype samples). */
  fileUrl?: string
}

/** "08/20/2026" → "Aug 20, 2026". Leaves anything else as is. */
function readableDate(value: string) {
  const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value)
  if (!match) return value
  const date = new Date(Number(match[3]), Number(match[1]) - 1, Number(match[2]))
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

function readableSize(bytes?: number) {
  if (bytes === undefined) return undefined
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

export function DocumentViewer({ document, onClose, pinned = false, onTogglePin, extraFacts }: {
  document: ViewerDocument | null
  onClose: () => void
  pinned?: boolean
  onTogglePin?: (document: ViewerDocument) => void
  /** Page-specific details, such as stage or a linked date. Shown after the type. */
  extraFacts?: (document: ViewerDocument) => Fact[]
}) {
  // Keep the last document while the viewer animates closed.
  const [shown, setShown] = useState(document)
  if (document && document !== shown) setShown(document)
  const current = document ?? shown
  const wide = useMediaQuery('(min-width: 1024px)')

  const [detailsOpen, setDetailsOpen] = useState(wide)
  const [zoom, setZoom] = useState(1)
  const [page, setPage] = useState(1)
  const [info, setInfo] = useState<PdfInfo | null>(null)
  const [failed, setFailed] = useState(false)
  const [stage, setStage] = useState<HTMLDivElement | null>(null)
  const [fitWidth, setFitWidth] = useState(640)

  // Fresh view for every document.
  const currentId = current?.id
  const [viewedId, setViewedId] = useState(currentId)
  if (currentId !== viewedId) {
    setViewedId(currentId)
    setZoom(1)
    setPage(1)
    setInfo(null)
    setFailed(false)
  }
  // Details follow the screen size whenever it crosses the breakpoint.
  const [layoutWide, setLayoutWide] = useState(wide)
  if (wide !== layoutWide) {
    setLayoutWide(wide)
    setDetailsOpen(wide)
  }

  // Fit pages to the stage width.
  useLayoutEffect(() => {
    if (!stage) return
    const measure = () => setFitWidth(Math.min(MAX_FIT_WIDTH, Math.max(240, stage.clientWidth - (wide ? 96 : 32))))
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(stage)
    return () => observer.disconnect()
  }, [stage, wide])

  const zoomIndex = ZOOM_STEPS.indexOf(zoom)
  const zoomOut = useCallback(() => setZoom((value) => ZOOM_STEPS[Math.max(0, ZOOM_STEPS.indexOf(value) - 1)]), [])
  const zoomIn = useCallback(() => setZoom((value) => ZOOM_STEPS[Math.min(ZOOM_STEPS.length - 1, ZOOM_STEPS.indexOf(value) + 1)]), [])

  useEffect(() => {
    if (!document) return
    function onKey(event: KeyboardEvent) {
      if (event.metaKey || event.ctrlKey || event.altKey) return
      if ((event.target as HTMLElement | null)?.closest('input, textarea')) return
      if (event.key === '+' || event.key === '=') zoomIn()
      else if (event.key === '-') zoomOut()
      else if (event.key === '0') setZoom(1)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [document, zoomIn, zoomOut])

  if (!current) return null

  const fileName = current.fileName || current.category
  const url = current.fileUrl ?? `/documents/${current.id}.pdf`
  const downloadName = fileName && /\.pdf$/i.test(fileName) ? fileName : `${current.name}.pdf`

  function download() {
    if (!current) return
    const link = window.document.createElement('a')
    link.href = url
    link.download = downloadName
    link.click()
    toast('Download started', { description: downloadName })
  }

  const facts: Fact[] = [
    { label: 'Type', value: current.name },
    ...(extraFacts?.(current) ?? []),
    { label: 'File', value: fileName || '—' },
    { label: 'Format', value: [`PDF`, readableSize(info?.bytes), info ? `${info.pages} ${info.pages === 1 ? 'page' : 'pages'}` : undefined].filter(Boolean).join(' · ') },
    { label: 'Added by', value: current.postedBy },
    { label: 'Uploaded', value: readableDate(current.uploadedAt) },
  ]

  let stageContent: ReactNode
  if (failed) {
    stageContent = (
      <Box className="doc-viewer-empty" role="status">
        <Box component="span" className="doc-viewer-empty-icon" aria-hidden="true"><DescriptionOutlined /></Box>
        <Typography variant="titleS" component="p">This preview isn’t available</Typography>
        <Typography variant="bodySStandard" color="text.secondary">You can still download the file and open it on your device.</Typography>
      </Box>
    )
  } else {
    stageContent = (
      <Suspense fallback={<div className="doc-viewer-page doc-viewer-page--loading" style={{ width: fitWidth, height: fitWidth * 11 / 8.5 }} aria-hidden="true" />}>
        <PdfPages key={url} url={url} width={Math.round(fitWidth * zoom)} scrollRoot={stage} onLoad={setInfo} onError={() => setFailed(true)} onPageChange={setPage} />
      </Suspense>
    )
  }

  return (
    <Dialog
      open={document !== null}
      onClose={onClose}
      fullScreen
      className="doc-viewer"
      aria-labelledby="doc-viewer-title"
      slotProps={{ paper: { className: 'doc-viewer-paper' } }}
    >
      <Box component="header" className="doc-viewer-bar">
        <Box className="doc-viewer-bar-start">
          <Box className="doc-viewer-title">
            <Typography component="h2" variant="titleXS" id="doc-viewer-title" noWrap>{current.name}</Typography>
            {fileName && <Typography variant="labelS" component="p" color="text.secondary" noWrap>{fileName}</Typography>}
          </Box>
        </Box>

        {failed ? <Box aria-hidden="true" /> : (
          <Box className="doc-viewer-bar-center">
            <Typography variant="labelS" component="span" className="doc-viewer-pages" aria-live="polite">
              {info ? <>Page {page} of {info.pages}</> : 'Loading…'}
            </Typography>
            <Box className="doc-viewer-zoom" role="group" aria-label="Zoom">
              <PlaceIconButton size="small" onClick={zoomOut} disabled={zoomIndex <= 0} aria-label="Zoom out"><RemoveRounded fontSize="small" /></PlaceIconButton>
              <Button size="small" variant="text" onClick={() => setZoom(1)} className="doc-viewer-zoom-value" aria-label={`Zoom ${Math.round(zoom * 100)} percent. Reset to fit width`}>{Math.round(zoom * 100)}%</Button>
              <PlaceIconButton size="small" onClick={zoomIn} disabled={zoomIndex >= ZOOM_STEPS.length - 1} aria-label="Zoom in"><AddRounded fontSize="small" /></PlaceIconButton>
            </Box>
          </Box>
        )}

        <Box className="doc-viewer-bar-end">
          {wide
            ? <Button variant="contained" color="primary" startIcon={<FileDownloadOutlined />} onClick={download} className="doc-viewer-download">Download</Button>
            : <Tooltip title="Download"><PlaceIconButton onClick={download} aria-label={`Download ${downloadName}`}><FileDownloadOutlined fontSize="small" /></PlaceIconButton></Tooltip>}
          {onTogglePin && (
            <Tooltip title={pinned ? 'Unpin' : 'Pin to the top of your documents'}>
              <PlaceIconButton onClick={() => onTogglePin(current)} aria-pressed={pinned} aria-label={pinned ? `Unpin ${current.name}` : `Pin ${current.name}`} className="doc-viewer-pin">
                {pinned ? <PushPin fontSize="small" /> : <PushPinOutlined fontSize="small" />}
              </PlaceIconButton>
            </Tooltip>
          )}
          <Tooltip title={detailsOpen ? 'Hide details' : 'Show details'}>
            <PlaceIconButton onClick={() => setDetailsOpen(!detailsOpen)} aria-pressed={detailsOpen} aria-controls="doc-viewer-details" aria-label="Details"><InfoOutlined fontSize="small" /></PlaceIconButton>
          </Tooltip>
          <Box component="span" className="doc-viewer-divider" aria-hidden="true" />
          <Tooltip title="Close">
            <PlaceIconButton onClick={onClose} aria-label="Close document"><CloseOutlined /></PlaceIconButton>
          </Tooltip>
        </Box>
      </Box>

      <Box className={`doc-viewer-main${detailsOpen ? ' has-details' : ''}`}>
        <Box ref={setStage} className="doc-viewer-stage" tabIndex={0} aria-label={`${current.name} pages`}>
          <Box className="doc-viewer-stage-inner">{stageContent}</Box>
        </Box>

        {!wide && <Box className={`doc-viewer-scrim${detailsOpen ? ' is-open' : ''}`} onClick={() => setDetailsOpen(false)} aria-hidden="true" />}
        <Box component="aside" id="doc-viewer-details" className={`doc-viewer-details${detailsOpen ? ' is-open' : ''}`} aria-label="Document details" inert={!detailsOpen}>
          <Box className="doc-viewer-details-head">
            <Typography variant="labelS" component="p" className="doc-viewer-details-eyebrow">Details</Typography>
            {!wide && <PlaceIconButton size="small" onClick={() => setDetailsOpen(false)} aria-label="Hide details"><CloseOutlined fontSize="small" /></PlaceIconButton>}
          </Box>
          <Typography variant="titleS" component="p">{current.name}</Typography>
          {current.summary && <Typography variant="bodySStandard" color="text.secondary" className="doc-viewer-summary">{current.summary}</Typography>}
          <FactList facts={facts} layout="rows" className="doc-viewer-facts" />
          {pinned && (
            <Box className="doc-viewer-pinned-note">
              <PushPin aria-hidden="true" />
              <Typography variant="labelS" component="span">Pinned to the top of your documents</Typography>
            </Box>
          )}
        </Box>
      </Box>
    </Dialog>
  )
}
