export type TeamMember = {
  id: string
  name: string
  role: string
  initials: string
  photoUrl?: string
  phone?: string
  email?: string
}

export type TransactionViewer = {
  id: string
  name: string
  role: 'Seller' | 'Co-seller' | 'Buyer' | 'Co-buyer'
  initials: string
  photoUrl?: string
}

export type TimelineEvent = {
  id: string
  title: string
  description: string
  occurredAt: string
  actor: string
  type: 'task' | 'document' | 'listing' | 'showing' | 'note'
}

export type UpcomingDate = {
  id: string
  date: string
  title: string
  description: string
  guidance?: {
    explanation: string
    preparation: string
    /** Resources attached to this date. One shows as a direct chip; two or more open the date's explanation with a list. */
    resourceIds: string[]
    /** Web links attached to this date. They list in the date's explanation dialog and open in a new tab. */
    links?: DateLink[]
  }
}

export type DateLink = { id: string; title: string; url: string }

export type TransactionResource = {
  id: string
  title: string
  shortTitle?: string
  summary: string
  readingTime: string
  relevance: 'Useful now' | 'Coming up' | 'Good to know'
  sections: Array<{ title: string; body?: string; points?: string[]; html?: string }>
  questions: string[]
}

export type TransactionTask = {
  id: string
  name: string
  description: string
  assignee: string
  dueDate: string
}

export type AdvertisingEvent = {
  id: string
  platform: string
  action: string
  occurredAt: string
  postedBy: string
  /** Where this update lives (the live listing or post). When set, the row opens it in a new tab. */
  url?: string
}

export type ShowingFeedback = {
  id: string
  date: string
  showingType: string
  interest: number
  feedback: string
}

export type TeamNote = {
  id: string
  title: string
  body: string
  author: string
  authorPhotoUrl?: string
  createdAt: string
}

export type TransactionDocument = {
  id: string
  name: string
  category: string
  uploadedAt: string
  postedBy: string
  status: 'Ready to view' | 'Signature requested' | 'Signed'
  summary: string
  thumbnailUrl?: string
}
